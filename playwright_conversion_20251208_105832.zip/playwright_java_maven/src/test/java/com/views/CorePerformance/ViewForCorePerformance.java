package com.views.CorePerformance;

import java.awt.AWTException;
import java.io.IOException;

import com.generic.Pojo;
import com.generic.Utilities;
import com.generic.WrapperFunctions;
import com.pageFactory.CorePerformance.CorePerformancePage;

public class ViewForCorePerformance {
	
	private CorePerformancePage objCorePerformancePage;
	private Utilities objUtilities;
	private Pojo objPojo;
	private WrapperFunctions objWrapperFunctions;
	
	public ViewForCorePerformance(Pojo objPojo) {
		
		objCorePerformancePage = new CorePerformancePage(objPojo);
		objWrapperFunctions = objPojo.getObjWrapperFunctions();
		objUtilities = objPojo.getObjUtilities();
	}
	public void NavigateToPageFromUserDropDwn(String DrpDownOption )
	{
		objCorePerformancePage.NavigateToPageFromUserDropDwn(DrpDownOption);
	}
	public void clickOnMyActionsButton(String sButton)
	{
		objCorePerformancePage.clickOnMyActionsButton(sButton);
	}
	public void clickOnMyChangesButton(String sButton)
	{
		objCorePerformancePage.clickOnMyChangesButton(sButton);
	}
	public void clickOnExportToExcel(String option,String sECRNumber)
	{
		objCorePerformancePage.clickOnExportToExcel(option,sECRNumber);
	}
	public void selectKPIReportType(String ReportType) {
		objCorePerformancePage.selectKPIReportType(ReportType);
	}
	public void clickOnExportToExcelOnFAIReport(String sNumber)
	{
		objCorePerformancePage.clickOnExportToExcelOnFAIReport(sNumber);
	}
	public void SelectSearchCriteriaAndVerifyPageIsLoaded(String sSearchName) {
		objCorePerformancePage.SelectSearchCriteriaAndVerifyPageIsLoaded(sSearchName);
	}
	public void SelectCCRViewSearchAndVerifyPageLode(String sSearchName) {
		objCorePerformancePage.SelectCCRViewSearchAndVerifyPageLode(sSearchName);
	}
	public void selectBUOnTriadModulePage(String sBU) {
		objCorePerformancePage.selectBUOnTriadModulePage(sBU);
	}
	public void clickonFirstNuminTable() {
		objCorePerformancePage.clickonFirstNuminTable();
	}
	public void enterProductsAndProjectPageDataAndClickOnButton(String sBusinessUnit,String sStatus,String sProductAndProjectButtonToClick) {
		if (sBusinessUnit != "")
			objCorePerformancePage.selectProductsAndProjectDropDownValue("Business Unit", sBusinessUnit);
		if (sStatus != "")
			objCorePerformancePage.selectProductsAndProjectDropDownValue("Status", sStatus);
		if (sProductAndProjectButtonToClick != "")
			objCorePerformancePage.clickOnProductAndProjectButton(sProductAndProjectButtonToClick);
	}
	public void selectBUOnCCBModulePage(String sBU) {
		objCorePerformancePage.selectBUOnCCBModulePage(sBU);
	}
	public void clickOnExportToExcelOnECOPMReview(){
		objCorePerformancePage.clickOnExportToExcelOnECOPMReview();
	}
	public boolean loginPageValidation() {
		// TODO Auto-generated method stub
		objCorePerformancePage.login();

		return false;
	}
	
}