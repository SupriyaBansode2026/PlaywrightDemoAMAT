package com.pageFactory.CorePerformance;

import java.util.List;
import java.util.Properties;

import com.generic.Pojo;
import com.generic.Utilities;
import com.generic.WrapperFunctions;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

/**
 * Playwright Page Object for CorePerformancePage.
 */
public class CorePerformancePage {
	
	private WrapperFunctions objWrapperFunctions;
	private Utilities objUtilities;
	private Pojo objPojo;
	private Page page;
	private Properties objConfig;
	boolean bResult=false;
	
	private Locator cmbBusinessUnit;
	private Locator cmbStatus;
	private Locator btnLoad;

	public CorePerformancePage(Pojo objPojo) {
		objUtilities = objPojo.getObjUtilities();
		objWrapperFunctions = objPojo.getObjWrapperFunctions();
		objConfig = objPojo.getObjConfig();
		page = objPojo.getPage();

		cmbBusinessUnit = page.locator("//div[text()='Business Unit']/following-sibling::div/select[@id='Business']");
		cmbStatus = page.locator("//div[text()='Status']/following-sibling::div/select[@id='Status']");
		btnLoad = page.locator("//a[contains(text(), 'Load')]");
	}
	
	public void clickOnMyActionsButton(String sButton)
	{
		Locator myActionButton = page.locator("//button[text()='" + sButton + "']");
		Locator WaitElement = page.locator("//*[@id='ActionGrid']//div[@class='k-virtual-scrollable-wrap']/table/tbody/tr[1]");
		String StartTime = objUtilities.getCurrentDateTime();
		if (!objWrapperFunctions.click(myActionButton))
			objUtilities.logReporter("Click on button "+sButton+" on My Actions", false, false);
		objUtilities.waitTillPageLoadSCVPerf(WaitElement);
		String EndTime = objUtilities.getCurrentDateTime(); 
		objUtilities.logReporter(sButton+"@~"+StartTime+"@~"+EndTime+"@~"+"NA", true, false);
	}
	
	public void NavigateToPageFromUserDropDwn(String DrpDownOption)
	{
		objUtilities.waitTillPageLoad(null);
		Locator UserName = page.locator("//span[@class = 'username']");
		objWrapperFunctions.click(UserName);
		Locator DropDownMenu = page.locator("//ul[@class = 'menu user_dropdown']/li/a[contains(text(),'"+DrpDownOption+"')]");
		String saction = "";
		Locator WaitElement = null;
		if(DrpDownOption.equalsIgnoreCase("My Actions")){
			saction = "My Actions Page";
			WaitElement = page.locator("//*[@id='ActionGrid']//div[@class='k-virtual-scrollable-wrap']/table/tbody/tr[1]");
		}
		else if(DrpDownOption.equalsIgnoreCase("My Changes")){
			saction = "My Changes Page";
			WaitElement = page.locator("//*[@id='ChangeGrid']//div[@class='k-virtual-scrollable-wrap']/table/tbody/tr[1]");
		}
		String StartTime = objUtilities.getCurrentDateTime();
		if(!objWrapperFunctions.click(DropDownMenu))
			objUtilities.logReporter("Click on "+DropDownMenu+" Hyper Link", false, false);	
		objUtilities.waitTillPageLoadSCVPerf(WaitElement);
		String EndTime = objUtilities.getCurrentDateTime();
		objUtilities.logReporter(saction+"@~"+StartTime+"@~"+EndTime+"@~"+"NA", true, false);
	}
	
	public void clickOnMyChangesButton(String sButton)
	{
		Locator myChangesButton = page.locator("//button[text()='" + sButton + "']");
		Locator FilterOption = page.locator("//*[@id='btnsch']/i");
		objWrapperFunctions.waitForElementToBeClickable("//*[@id='btnsch']/i");
		objWrapperFunctions.click(FilterOption);
		objUtilities.waitFor(8);
		Locator WaitElement = null;
		String StartTime = objUtilities.getCurrentDateTime();
		bResult = objWrapperFunctions.click(myChangesButton);
		if(!bResult)
			objUtilities.logReporter("Click on button "+sButton+" on My Changes", false, false);
		WaitElement = page.locator("//*[@id='loadingmychange']/p");
		objUtilities.waitTillPageLoadPerformance(WaitElement);
		String EndTime = objUtilities.getCurrentDateTime();
		objUtilities.logReporter(sButton+"@~"+StartTime+"@~"+EndTime+"@~"+"NA", true, false);
	}
	
	public void selectReportType(String option)
	{
		Locator reportType = page.locator("//select[@id='ReportType']");
		if(!objWrapperFunctions.selectDropDownOption(reportType, option, "text"))
			objUtilities.logReporter("Select Report type as  "+option+"  :selectReportType()", false, false);		
	}
	
	public void setECRNumber(String sECRNumber)
	{
		Locator ecrNoTextarea = page.locator("//textarea[@id='ECRNumbers']");
		if(!objWrapperFunctions.setText(ecrNoTextarea, sECRNumber))
			objUtilities.logReporter("Enter ECR Number " +sECRNumber+"  :setECRNumber()", false , false);
	}
	
	public void clickOnExportToExcel(String option, String sECRNumber)
	{
		this.selectReportType(option);
		this.setECRNumber(sECRNumber);
		
		Locator ExcelButton = page.locator("//button[@id='btnExportToExcel']");
		String StartTime = objUtilities.getCurrentDateTime();
		if(!objWrapperFunctions.click(ExcelButton))
			objUtilities.logReporter("Click on Export to excel button : clickOnExportToExcel()", false, false);	
		objUtilities.waitTillPageLoadPerformance(page.locator("//*[@id='loadingRpt']/p"));
		String sFileName = option+"_Report.xls"; 
		objUtilities.verifyFileFromDownloadedPathIfExist(sFileName);
		String EndTime = objUtilities.getCurrentDateTime();
		objUtilities.logReporter("Export to Excel("+option+")"+"@~"+StartTime+"@~"+EndTime+"@~"+sECRNumber, true, false);
	}
	
	public void selectKPIReportType(String ReportType) {
		Locator ReportTypeRadio = null;
		switch (ReportType.toLowerCase()) {
		case "standard":
			ReportTypeRadio = page.locator("//input[@id = 'standard' and @type = 'radio']");
			break;
		case "wip changes":
			ReportTypeRadio = page.locator("//input[@id = 'wipChanges' and @type = 'radio']");
			break;
		case "wip actions":
			ReportTypeRadio = page.locator("//input[@id = 'wipActions' and @type = 'radio']");
			break;
		case "cancelled":
			ReportTypeRadio = page.locator("//input[@id = 'cancelled' and @type = 'radio']");
			break;
		default:
			objUtilities.logReporter("Provided "+ReportType+" input not correct : selectKPIReportType()", false, false);
		}
		String StartTime = objUtilities.getCurrentDateTime();
		if(!objWrapperFunctions.selectRadioButton(ReportTypeRadio, true))
			objUtilities.logReporter("Select Report type as " + ReportType + " :selectReportType()", false, false);
		objUtilities.waitTillPageLoadSCVPerf(page.locator("//*[@id='btn_excelExport']"));
		String EndTime = objUtilities.getCurrentDateTime();
		objUtilities.logReporter(ReportType+"@~"+StartTime+"@~"+EndTime+"@~"+"NA", true, false);
	}
	
	public void setPartNumber(String sPartNumber)
	{
		Locator txtPartNumber = page.locator("//label[contains(text(),'Part Number')]/following-sibling::div/textarea");
		if(!objWrapperFunctions.setText(txtPartNumber, sPartNumber))
			objUtilities.logReporter("Enter Part number '"+sPartNumber+"' in Grace Period extention page : setPartNumber()", false , false);
	}
	
	public void clickOnExportToExcelOnFAIReport(String sNumber)
	{
		this.setPartNumber(sNumber);
		Locator ExcelButton = page.locator("//*[@id='btnExportExcel']");
		String StartTime = objUtilities.getCurrentDateTime();
		if(!objWrapperFunctions.click(ExcelButton))
			objUtilities.logReporter("Click on Export to excel button : clickOnExportToExcelOnFAIReport()", false, false);	
		objUtilities.waitTillPageLoadPerformance(page.locator("//*[@id='ExportMsg']"));
		String sFileName = "Qual GPE Report.xlsx"; 
		objUtilities.verifyFileFromDownloadedPathIfExist(sFileName);
		String EndTime = objUtilities.getCurrentDateTime();
		objUtilities.logReporter("Export to Excel(Qual GPE Report)"+"@~"+StartTime+"@~"+EndTime+"@~"+sNumber, true, false);
	}
	
	public void clickOnCRNAdvancedSearch() {
		Locator xpath = page.locator("//a[contains(@href,'CRNSearch/AdvancedSearch')]");
		if(!objWrapperFunctions.click(xpath))
			objUtilities.logReporter("click on CRN advanced search:clickOnCRNAdvancedSearch()", false, false);
	}
	
	public void clickOnRevItemComponentSearch() {
		Locator xpath = page.locator("//a[contains(@href,'Search/RevItemcomponent')]");
		if(!objWrapperFunctions.click(xpath))
			objUtilities.logReporter("click on Rev Item Component clickOnRevItemComponentSearch()", false, false);
	}
	
	public void ClickOnSubMenuSystem() {
		Locator SystemBtn = page.locator("//ul[@id='CoreMenu']//li//a[contains(text(), 'System')]");
		if(!objWrapperFunctions.click(SystemBtn))
			objUtilities.logReporter("Click on BU Submenu of System in Search :ClickOnSubMenuSystem()", false, false);
	}
	
	public void SelectSearchCriteriaAndVerifyPageIsLoaded(String sSearchName) {
		String StartTime = objUtilities.getCurrentDateTime();
		if(sSearchName.equalsIgnoreCase("CRN Advanced Search"))
		{
			objUtilities.clickMenuOptionPerformace(false, "Search", "");
			this.clickOnCRNAdvancedSearch();
		}
		else if(sSearchName.equalsIgnoreCase("Rev. Item/Component"))
		{
			objUtilities.clickMenuOptionPerformace(false, "Search", "");
			this.clickOnRevItemComponentSearch();
		}
		else if(sSearchName.equalsIgnoreCase("System"))
		{
			objUtilities.clickMenuOptionPerformace(false, "Search", "");
			this.ClickOnSubMenuSystem();
		}
		else
		{
			objUtilities.clickMenuOptionPerformace(false, "Search", sSearchName);
		}	
		objUtilities.verifySearchPageIsLoadedPerformance(sSearchName);
		String EndTime = objUtilities.getCurrentDateTime();
		objUtilities.logReporter(sSearchName+"@~"+StartTime+"@~"+EndTime+"@~"+"NA", true, false);
	}
	
	public void SelectCCRViewSearchAndVerifyPageLode(String sSearchName) {
		String StartTime = objUtilities.getCurrentDateTime();
		objUtilities.clickMenuOptionPerformace(false, "Search", "");
		this.ClickOnCCRViews();
		if(sSearchName.equalsIgnoreCase("BU"))
			this.clickOnBU();
		else if(sSearchName.equalsIgnoreCase("Release Date"))
			this.clickOnReleaseDate();
		else
			this.ClickOnDetailSubMenuOnCCR(sSearchName);
		objUtilities.verifySearchPageIsLoadedPerformance(sSearchName);
		String EndTime = objUtilities.getCurrentDateTime();
		objUtilities.logReporter(sSearchName+"@~"+StartTime+"@~"+EndTime+"@~"+"NA", true, false);
	}
	
	public void ClickOnCCRViews() {
		Locator CCRViewsBtn = page.locator("//ul[@id='CoreMenu']//li//span[contains(text(),'CCR Views')]");
		if(!objWrapperFunctions.click(CCRViewsBtn))
			objUtilities.logReporter("Click on BU Submenu of CCR in Search :ClickOnSubMenuOnCCR()", false, false);
	}
	
	public void clickOnBU()
	{
		Locator BU = page.locator("//li/ul[@id='CoreMenu']//li/a[text()='BU ']");
		if(!objWrapperFunctions.click(BU))
			objUtilities.logReporter("Click on BU:clickOnBU()", false, false);
	}
	
	public void clickOnReleaseDate()
	{
		Locator ReleaseDate = page.locator("//ul[@id='CoreMenu']//li//a[contains(text(),'Release Date')]");
		if(!objWrapperFunctions.click(ReleaseDate))
			objUtilities.logReporter("Click on Release date:clickOnReleaseDate()", false, false);
	}
	
	public void ClickOnDetailSubMenuOnCCR(String sCCRSubMenu) {
		Locator CCRSubMenu = page.locator("//ul[@id='CoreMenu']//li//a[contains(text(),'"+sCCRSubMenu+"')]");
		if(!sCCRSubMenu.isEmpty()) {
			boolean bResult = false;
			List<Locator> objCCRMenu = page.locator("//ul[@id='CoreMenu']//li//a[contains(text(),'"+sCCRSubMenu+"')]").all();
			for(Locator objCCRele : objCCRMenu) {
				objWrapperFunctions.waitForElementPresence("//ul[@id='CoreMenu']//li//a[contains(text(),'"+sCCRSubMenu+"')]");
				if(objCCRele.textContent().trim().equalsIgnoreCase(sCCRSubMenu)) {
					bResult = objWrapperFunctions.click(CCRSubMenu);
					break;
				}
			}
			if(!bResult)
				objUtilities.logReporter("Click on " +sCCRSubMenu+ " Submenu of CCR in Search :ClickOnSubMenuOnCCR()", bResult, false);
		}
	}
	
	public void selectBUOnTriadModulePage(String sBU) {
		Locator BUSelect = page.locator("//div[@class='panel-heading' and text()='Others']//parent::div//div[contains(text(),'" + sBU + "')]");
		String StartTime = objUtilities.getCurrentDateTime();
		if(!objWrapperFunctions.click(BUSelect))
			objUtilities.logReporter("Select BU On Traid Module Page - "+sBU+" : selectBUOnTriadModulePage()", false, false);
		objUtilities.waitTillPageLoadSCVPerf(page.locator("//table[@role='treegrid']/tbody/tr/td[2]/a")); 
		String EndTime = objUtilities.getCurrentDateTime();
		objUtilities.logReporter("View PCR page for BU "+sBU+"@~"+StartTime+"@~"+EndTime+"@~"+"NA", true, false);
	}
	
	public void clickonFirstNuminTable() {
		objUtilities.waitTillPageLoad(null);
		Locator lnkNumber = page.locator("//table[@role='treegrid']/tbody/tr/td[2]/a").first();
		objWrapperFunctions.checkElementDisplyed(lnkNumber);
		String sPCRNo = objWrapperFunctions.getText(lnkNumber, "text");
		System.out.println(sPCRNo);
		lnkNumber.press("Enter");
		lnkNumber.click();
		String StartTime = objUtilities.getCurrentDateTime();
		objUtilities.switchToTabBasedOnIndex(1);
		objUtilities.waitTillPageLoadSCVPerf(page.locator("//*[@id='lblEC_Number'][text()='"+sPCRNo+"']"));
		String EndTime = objUtilities.getCurrentDateTime();
		objUtilities.logReporter("open PCR from PCR review page"+"@~"+StartTime+"@~"+EndTime+"@~"+"NA", true, false);
	}
	
	public void selectProductsAndProjectDropDownValue(String sDropDownName, String sDropDownValue) {
		Locator objWEDropDown = null;
		switch (sDropDownName.toLowerCase()) {
		case "business unit":
			objWEDropDown = cmbBusinessUnit;
			break;
		case "status":
			objWEDropDown = cmbStatus;
			break;
		default:
			objUtilities.logReporter("Wrong drop down name passed as " + sDropDownName, false, false);
		}
		if(!objWrapperFunctions.selectDropDownOption(objWEDropDown, sDropDownValue, "text"))
			objUtilities.logReporter("Select value '" + sDropDownValue + "' in dropdown '" + sDropDownName+ "' in method 'selectProductsAndProjectDropDownValue'", false, false);
	}
	
	public void clickOnProductAndProjectButton(String sButtonName) {
		Locator objWEButton = null;
		switch (sButtonName.toLowerCase()) {
		case "load":
			objWEButton = btnLoad;
			break;
		default:
			objUtilities.logReporter("Wrong button passed to click as '" + sButtonName + "' in method 'clickOnProductAndProjectButton'", false, false);
		}
		String StartTime = objUtilities.getCurrentDateTime();
		if(!objWrapperFunctions.click(objWEButton))
			objUtilities.logReporter("Click on Product and Project button '" + sButtonName+ "' in method 'clickOnProductAndProjectButton'", false, false);
		objUtilities.waitTillPageLoadSCVPerf(page.locator("//*[@id='example-basic']//tbody//tr//td[starts-with(@id, 'EcId')]"));
		String EndTime = objUtilities.getCurrentDateTime();
		objUtilities.logReporter("P2 page (Load Button)"+"@~"+StartTime+"@~"+EndTime+"@~"+"NA", true, false);
	}
	
	public void selectBUOnCCBModulePage(String sBU) {
		Locator BUSelect = page.locator("//div[@class='panel-heading' and text()='SSG BUs']//parent::div//div[contains(text(),'" + sBU + "')]");
		String StartTime = objUtilities.getCurrentDateTime();
		if(!objWrapperFunctions.click(BUSelect))
			objUtilities.logReporter("Select BU On CCB Module Page - "+sBU+" : selectBUOnCCBModulePage()", false, false);
		objUtilities.waitTillPageLoadSCVPerf(page.locator("//*[@id='ECOPMGrid']//table"));
		String EndTime = objUtilities.getCurrentDateTime();
		objUtilities.logReporter("Live CCB page for BU "+sBU+"@~"+StartTime+"@~"+EndTime+"@~"+"NA", true, false);
	}
	
	public void clickOnExportToExcelOnECOPMReview()
	{
		Locator ExcelButton = page.locator("//*[@id='btnExcelExport_ECOPMGrid']");
		String StartTime = objUtilities.getCurrentDateTime();
		if(!objWrapperFunctions.click(ExcelButton))
			objUtilities.logReporter("Click on Export to excel button : clickOnExportToExcelOnECOPMReview()", false, false);
		objUtilities.waitTillPageLoadPerformance(page.locator("//*[@id='ExportMsg']"));
		String sFileName = "ECOPMECExport.xlsx";
		objUtilities.verifyFileFromDownloadedPathIfExist(sFileName);
		String EndTime = objUtilities.getCurrentDateTime();
		objUtilities.logReporter("ECO PM Review (Export to Excel)"+"@~"+StartTime+"@~"+EndTime+"@~NA", true, false);
	}

	public void login() {
		Locator loc_loc1 = page.locator("//input[@id='txtUsername']");
		Locator loc_pswrd = page.locator("//input[@id='txtPassword']");
		objUtilities.logReporter("Enter value of username::", objWrapperFunctions.setText(loc_loc1,"admin"), false);
		// TODO Auto-generated method stub
	}
}